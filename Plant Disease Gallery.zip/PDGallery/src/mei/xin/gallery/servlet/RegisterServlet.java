package mei.xin.gallery.servlet;

import mei.xin.gallery.model.User;
import mei.xin.gallery.service.LoginService;
import mei.xin.gallery.service.LoginServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/registerServlet")
public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String email = request.getParameter("email");
        String sex = request.getParameter("sex");
        String tel = request.getParameter("tel");
        String[] usertype = request.getParameterValues("usertype");

        String usertypelist = "";
        for (String ut:usertype) {
            usertypelist = usertypelist + ut;
        }
        // todo 用户身份 trim() 使用空格切割

        LoginService loginService = new LoginServiceImpl();
        User user = new User();

        user.setUsername(username);
        user.setPassword(password);
        user.setEmail(email);
        user.setSex(sex);
        user.setTel(tel);
        user.setUsertype(usertypelist);

        List<Object> res = loginService.register(user);

        if ((boolean) res.get(0)) {
            List<Object> resl = loginService.checkUser(username, password);
//            request.setCharacterEncoding("utf-8");
//            response.setCharacterEncoding("utf-8");
//            response.setContentType("text/html;charset=utf-8");
//            response.getWriter().print("<script>alert('用户：" + username + "注册成功，已自动登录')</script>");
            request.setAttribute("regseccuss", "注册成功！");
            request.getSession().setAttribute("user", user);
            request.getRequestDispatcher("login.jsp");
        } else {
            request.setAttribute("registertip", res.get(1));
            request.getRequestDispatcher("register.jsp").forward(request, response);
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
