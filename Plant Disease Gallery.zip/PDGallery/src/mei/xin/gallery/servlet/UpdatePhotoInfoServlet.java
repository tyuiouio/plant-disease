package mei.xin.gallery.servlet;

import mei.xin.gallery.dao.ElementDao;
import mei.xin.gallery.model.Element;
import mei.xin.gallery.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/updatePhotoInfoServlet")
public class UpdatePhotoInfoServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        User user = (User) request.getSession().getAttribute("user");
        Element element = (Element) request.getSession().getAttribute("updateelement");
        String eidstr = request.getParameter("eid");

        if (null == user || element == null || eidstr.equals("")) {
            request.setAttribute("updatephotoinfotip", "url参数错误或请先登录！");
        } else {


            String title = request.getParameter("title");
            String text = request.getParameter("text");
            String label = request.getParameter("label");
            String diseasespestsinfo = request.getParameter("diseasespestsinfo");
            int markuserid = user.getUserid();
            String didstr = request.getParameter("did");
            int did = Integer.parseInt(didstr);

            element.setTitle(title);
            element.setText(text);
            element.setLabel(label);
            element.setDiseasespestsinfo(diseasespestsinfo);
            element.setMarkuserid(markuserid);
            element.setDid(did);

            int i = ElementDao.UpdateInfo(element);
            if (i==1){
                request.getSession().setAttribute("updateelement",element);
                request.setAttribute("updatephotoinfotip", "更新成功！");
            }else{
                request.setAttribute("updatephotoinfotip", "写入数据库失败！");
            }

        }
        request.getRequestDispatcher("updatephotoinfo.jsp").forward(request, response);


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
