package mei.xin.gallery.servlet;

import mei.xin.gallery.dao.CommentDao;
import mei.xin.gallery.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/deleteCommentServlet")
public class DeleteCommentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String coidstr = request.getParameter("coid");
        int coid = Integer.parseInt(coidstr);
        int i = 0;
        User user = (User) request.getSession().getAttribute("user");
        try {
            i = CommentDao.deleteCommentByUserAndCoid(user, coid);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        if (i == 1) {
            request.setAttribute("mycommenttips","删除成功！");
        } else {
            request.setAttribute("mycommenttips","删除失败！");
        }
        request.getRequestDispatcher("mycomment.jsp").forward(request, response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
