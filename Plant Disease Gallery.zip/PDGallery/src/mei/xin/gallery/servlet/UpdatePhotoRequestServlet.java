package mei.xin.gallery.servlet;

import mei.xin.gallery.dao.ElementDao;
import mei.xin.gallery.model.Element;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/pdatePhotoRequestServlet")
public class UpdatePhotoRequestServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String eidstr = request.getParameter("eid");
        if (eidstr != null) {
            int eid = Integer.parseInt(eidstr);
            Element element = ElementDao.getByEid(eid);
            if (element != null) {
                request.getSession().setAttribute("updateelement", element);
            } else {
                request.setAttribute("updatephotoinfotip", "元素ID参数错误！");
            }
        } else {
            request.setAttribute("updatephotoinfotip", "url-eid参数错误！");
        }
        request.getRequestDispatcher("updatephotoinfo.jsp").forward(request, response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
