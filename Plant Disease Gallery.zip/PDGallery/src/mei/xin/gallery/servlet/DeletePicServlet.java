package mei.xin.gallery.servlet;

import mei.xin.gallery.service.UploadPhotoService;
import mei.xin.gallery.service.UploadPhotoServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deletepicServlet")
public class DeletePicServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int eid  = Integer.parseInt(request.getParameter("eid"));
        UploadPhotoService uploadPhotoService = new UploadPhotoServiceImpl();
        int i = uploadPhotoService.DeletePicByEid(eid);
        if (i==1){
            request.setAttribute("mypiclisttip","删除成功！");
        }else{
            request.setAttribute("mypiclisttip","删除失败！");
        }
        request.getRequestDispatcher("myuploadpic.jsp").forward(request,response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
