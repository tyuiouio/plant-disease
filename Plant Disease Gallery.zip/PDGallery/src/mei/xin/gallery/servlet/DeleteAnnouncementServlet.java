package mei.xin.gallery.servlet;

import mei.xin.gallery.dao.AnnouncementDao;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/deleteAnnouncementServlet")
public class DeleteAnnouncementServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String anidstr = request.getParameter("anid");
        int anid = Integer.parseInt(anidstr);
        int i = AnnouncementDao.deleteAnnouncementByAnid(anid);
        if(i==1){
            request.setAttribute("deleteanntip","删除成功！");
        }else{
            request.setAttribute("deleteanntip","删除失败！");
        }
        request.getRequestDispatcher("announcement.jsp").forward(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }
}
