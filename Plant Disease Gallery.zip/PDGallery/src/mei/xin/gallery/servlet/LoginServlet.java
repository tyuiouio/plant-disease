package mei.xin.gallery.servlet;

import mei.xin.gallery.model.User;
import mei.xin.gallery.service.LoginService;
import mei.xin.gallery.service.LoginServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String url = "/login.jsp";

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        if (username == null || password == null) {
            request.setAttribute("logintip", "用户名或密码不能为空！");
        } else {

            LoginService loginService = new LoginServiceImpl();
            List<Object> res = loginService.checkUser(username, password);

            if ((boolean) res.get(0)) {
                User user = (User) res.get(1);
                if (user.getIsdelete() == 1) {
                    request.setAttribute("logintip", "用户账户已冻结！");
                } else {
                    request.getSession().setAttribute("user", user);
                    request.getSession().setAttribute("username", user.getUsername());
                    url = "/index.jsp";

                }
            } else {
                request.setAttribute("logintip", "用户名密码错误！");
                url = "/login.jsp";
            }
        }
        RequestDispatcher dispatch = request.getRequestDispatcher(url);
        dispatch.forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {
        doPost(request, response);
    }
}
