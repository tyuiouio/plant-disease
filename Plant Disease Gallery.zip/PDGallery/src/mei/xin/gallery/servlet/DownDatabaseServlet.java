package mei.xin.gallery.servlet;

import mei.xin.gallery.common.DateUtils;
import mei.xin.gallery.dao.ElementDao;
import mei.xin.gallery.dao.PoolDao;
import mei.xin.gallery.model.Element;
import mei.xin.gallery.model.Pool;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;


@WebServlet("/downdatabaseServlet")
public class DownDatabaseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setCharacterEncoding("UTF-8");
        String didstr = request.getParameter("did");
        if (didstr != null && !didstr.equals("")) {
            int did = Integer.parseInt(didstr);
            List<Element> elements = ElementDao.GetAllUploadPicByDbDid(did);

            response.setContentType("APPLICATION/OCTET-STREAM");
            response.setHeader("Content-Disposition", "attachment; filename=" + did + "_" +this.getZipFilename(did));

            System.out.println("Download...");
            ZipOutputStream zos = new ZipOutputStream(response.getOutputStream());


            String[] filenamelist = new String[elements.size()];
            for (int i = 0; i < elements.size(); i++) {
                filenamelist[i] = elements.get(i).getFilename();
            }

//            for (int i = 0; i < elements.size(); i++) {
//                System.err.println(filenamelist[i]);
//            }

            String fileSaveRootPath = "/Users/meixin/Documents/IdeaProjects/PDGallery/web/photodb/";

            File[] files = new File[elements.size()];

            for (int i = 0; i < elements.size(); i++) {
                files[i] = new File(fileSaveRootPath + filenamelist[i]);
            }

            for (File f : files) {
                zipFile(f, "", zos);
            }

            zos.flush();
            zos.close();

            request.setAttribute("downdbtip", "下载成功！");

        } else {
            request.setAttribute("downdbtip", "参数错误，下载失败！");
        }
        request.getRequestDispatcher("databaselist.jsp").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    private void zipFile(File subs, String baseName, ZipOutputStream zos) throws IOException {
        if (subs.exists()) {
            if (subs.isFile()) {
                zos.putNextEntry(new ZipEntry(baseName + subs.getName()));
                FileInputStream fis = new FileInputStream(subs);
                byte[] buffer = new byte[1024];
                int r = 0;
                while ((r = fis.read(buffer)) != -1) {
                    zos.write(buffer, 0, r);
                }
                fis.close();
            } else {
                //如果是目录。递归查找里面的文件
                String dirName = baseName + subs.getName() + "/";
                zos.putNextEntry(new ZipEntry(dirName));
                File[] sub = subs.listFiles();
                for (File f : sub) {
                    zipFile(f, dirName, zos);
                }
            }
        }

    }

    private String getZipFilename(int did) {
        return DateUtils.getNowDateInFile() + ".zip";
    }
}
