package mei.xin.gallery.servlet;

import mei.xin.gallery.model.User;
import mei.xin.gallery.service.UpdateUserInfoService;
import mei.xin.gallery.service.UpdateUserInfoServiceImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/updateUserInfoServlet")
public class UpdateUserInfoServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("utf-8");
        response.setCharacterEncoding("utf-8");
        response.setContentType("text/html;charset=utf-8");

        User user = (User) request.getSession().getAttribute("user");
        if (user != null) {

            String username_temp = request.getParameter("username");
            String password_temp = request.getParameter("password");
            String password2_temp = request.getParameter("password2");
            String email_temp = request.getParameter("email");
            String tel_temp = request.getParameter("tel");
            String sex_temp = request.getParameter("sex");

            if (username_temp != "") {
                user.setUsername(username_temp);
            }
            if (password_temp != "" || password2_temp != "") {
                if (password2_temp.equals(user.getPassword())) {
                    user.setPassword(password2_temp);
                } else {
                    request.setAttribute("updateinfotip", "密码不一致！");
                    RequestDispatcher dispatch = request.getRequestDispatcher("/userpage.jsp");
                    dispatch.forward(request, response);
                }
            }
            if (tel_temp != "") {
                user.setTel(tel_temp);
            }
            if (email_temp != "") {
                user.setEmail(email_temp);
            }
            user.setSex(sex_temp);

            List<Object> i = null;
            UpdateUserInfoService updateUserInfoService = new UpdateUserInfoServiceImpl();
            try {
                i = updateUserInfoService.updateuserinfo(user);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if ((boolean)i.get(0) == true) {
                request.setAttribute("updateinfotip", "修改成功！");
                RequestDispatcher dispatch = request.getRequestDispatcher("/userpage.jsp");
                dispatch.forward(request, response);
            } else {
                request.setAttribute("updateinfotip", "修改失败！");
                RequestDispatcher dispatch = request.getRequestDispatcher("/userpage.jsp");
                dispatch.forward(request, response);
            }

        } else {
            request.setAttribute("logintip", "请先登录！");
            RequestDispatcher dispatch = request.getRequestDispatcher("/login.jsp");
            dispatch.forward(request, response);
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
