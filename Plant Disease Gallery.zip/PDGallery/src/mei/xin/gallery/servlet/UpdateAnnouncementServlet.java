package mei.xin.gallery.servlet;

import mei.xin.gallery.common.DateUtils;
import mei.xin.gallery.dao.AnnouncementDao;
import mei.xin.gallery.model.Announcement;
import mei.xin.gallery.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Timestamp;

@WebServlet("/updateAnnouncementServlet")
public class UpdateAnnouncementServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String active = request.getParameter("active");

        if (active.equals("1")) {
            String title = request.getParameter("title");
            String text = request.getParameter("text");
            String link = request.getParameter("link");

            User user = (User) request.getSession().getAttribute("user");

            int userid = user.getUserid();

            Announcement announcement = new Announcement();

            announcement.setUserid(userid);
            announcement.setTitle(title);
            announcement.setText(text);
            announcement.setText(link);

            AnnouncementDao.addAnnouncement(announcement);

            response.sendRedirect("announcement.jsp");
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
