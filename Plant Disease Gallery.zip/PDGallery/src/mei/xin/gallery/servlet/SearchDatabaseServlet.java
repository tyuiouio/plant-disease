package mei.xin.gallery.servlet;

import mei.xin.gallery.dao.AnnouncementDao;
import mei.xin.gallery.dao.ElementDao;
import mei.xin.gallery.dao.PoolDao;
import mei.xin.gallery.model.Announcement;
import mei.xin.gallery.model.Element;
import mei.xin.gallery.model.Pool;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/searchDatabaseServlet")
public class SearchDatabaseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String search_db_key = request.getParameter("search_db_key");
        String didstr = request.getParameter("did");

        List<Element> elements = new ArrayList<Element>();

        if(didstr!=null){
            int did = Integer.parseInt(didstr);
            elements = ElementDao.getByDid(did);
            String dname = PoolDao.getPoolNameByDid(did);
            request.setAttribute("search_db_key",dname+"数据库");
        }

        if (search_db_key != null ){
            elements = ElementDao.searchElementsByKey(search_db_key);
            request.setAttribute("search_db_key", search_db_key);
        }

        request.setAttribute("elements", elements);
        request.getRequestDispatcher("searchdatabase.jsp").forward(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
