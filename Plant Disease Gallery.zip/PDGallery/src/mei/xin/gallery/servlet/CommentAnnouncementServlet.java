package mei.xin.gallery.servlet;

import mei.xin.gallery.common.DateUtils;
import mei.xin.gallery.dao.CommentDao;
import mei.xin.gallery.model.Comment;
import mei.xin.gallery.model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/commentAnnouncementServlet")
public class CommentAnnouncementServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String anidstr = request.getParameter("anid");
        if (anidstr == null) {
            request.setAttribute("commentAnnouncementTip", "参数错误！");
            request.getRequestDispatcher("commentAnnouncement.jsp").forward(request, response);
            return;
        }
        int anid = Integer.parseInt(anidstr);

        User user = (User) request.getSession().getAttribute("user");
        if (user == null) {
            request.setAttribute("commentAnnouncementTip", "请先登录！<a href='login.jsp'>点击跳转登录页面</a>");
            request.getRequestDispatcher("commentAnnouncement.jsp").forward(request, response);
            return;
        }

        String content = request.getParameter("content");
        System.out.println(content);
        if (content == null || content.equals("")) {
            request.setAttribute("commentAnnouncementTip", "评论为空！");
            request.getRequestDispatcher("commentAnnouncement.jsp").forward(request, response);
            return;
        }

        Comment comment = new Comment();
        comment.setToanid(anid);
        comment.setUserid(user.getUserid());
        comment.setText(content);
        comment.setSendtime(DateUtils.getNowDate());

        int i = CommentDao.addComment(comment);

        if (i == 1) {
            request.setAttribute("commentAnnouncementTip", "评论发送成功!");
        } else {
            request.setAttribute("commentAnnouncementTip", "评论发送失败!");
        }

        request.getRequestDispatcher("commentAnnouncement.jsp").forward(request, response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }
}
