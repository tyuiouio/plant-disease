package mei.xin.gallery.dao;

import mei.xin.gallery.common.DataBaseUtils;
import mei.xin.gallery.model.Pool;
import mei.xin.gallery.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PoolDao {

    public static List<Pool> getAllPool() {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Pool> result = new ArrayList<Pool>();
        result.clear();

        String sql = "select * from databasepool";
        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                int did = rs.getInt("did");
                String dname = rs.getString("dname");
                String introduction = rs.getString("introduction");
                String link = rs.getString("link");
                String logo = rs.getString("logo");
                Pool pool = new Pool(did, dname, introduction, link, logo);
                result.add(pool);
            }
        } catch (
                SQLException e) {
            result.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return result;
    }

    public static String getPoolNameByDid(int did) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String dname = "";

        String sql = "select dname from databasepool where did = ?";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1,did);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                dname = rs.getString("dname");
            }
        } catch (
                SQLException e) {

            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return dname;
    }
}
