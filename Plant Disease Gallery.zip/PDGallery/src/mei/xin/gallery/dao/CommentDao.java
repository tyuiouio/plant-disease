package mei.xin.gallery.dao;

import mei.xin.gallery.common.DataBaseUtils;
import mei.xin.gallery.model.Announcement;
import mei.xin.gallery.model.Comment;
import mei.xin.gallery.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CommentDao {
    public static List<Comment> getAllCommentsByToanid(int toanidin) {
        List<Comment> res = new ArrayList<Comment>();
        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        res.clear();

        String sql = "select * from comment where toanid=? and isdelete=0";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, toanidin);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                int coid = rs.getInt("coid");
                String commenttype = rs.getString("commenttype");
                int arid = rs.getInt("arid");
                int anid = rs.getInt("anid");
                int userid = rs.getInt("userid");
                String totype = rs.getString("totype");
                int touserid = rs.getInt("touserid");
                int toarid = rs.getInt("toarid");
                int toanid = rs.getInt("toanid");
                int isdelete = rs.getInt("isdelete");
                String text = rs.getString("text");
                int click = rs.getInt("click");
                String sendtime = rs.getString("sendtime");
                Comment comment = new Comment(coid, commenttype, arid, anid, userid, totype, touserid, toarid, toanid, isdelete, text, click, sendtime);
                res.add(comment);
//                System.err.println(comment.toString());
            }
        } catch (
                SQLException e) {
            res.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }

        return res;
    }


    public static List<Comment> getCommentsByUserid(int useridin) {

        List<Comment> res = new ArrayList<Comment>();
        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        res.clear();

        String sql = "select * from comment where userid=? and isdelete=0";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, useridin);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                int coid = rs.getInt("coid");
                String commenttype = rs.getString("commenttype");
                int arid = rs.getInt("arid");
                int anid = rs.getInt("anid");
                int userid = rs.getInt("userid");
                String totype = rs.getString("totype");
                int touserid = rs.getInt("touserid");
                int toarid = rs.getInt("toarid");
                int toanid = rs.getInt("toanid");
                int isdelete = rs.getInt("isdelete");
                String text = rs.getString("text");
                int click = rs.getInt("click");
                String sendtime = rs.getString("sendtime");
                Comment comment = new Comment(coid, commenttype, arid, anid, userid, totype, touserid, toarid, toanid, isdelete, text, click, sendtime);
                res.add(comment);
            }
        } catch (
                SQLException e) {
            res.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }

        return res;

    }

    public static int deleteCommentByCoid(int coidin) throws SQLException {
        String sql = "delete from comment where coid = ?";
        Connection connection = DataBaseUtils.getConnection();
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, coidin);
        int i = pstmt.executeUpdate();
        DataBaseUtils.relaseResouce(null, pstmt, connection);
        return i;
    }

    public static int deleteCommentByUserAndCoid(User user, int coidin) throws SQLException {
        String sql = "delete from comment where coid = ? and userid =?";
        Connection connection = DataBaseUtils.getConnection();
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setInt(1, coidin);
        pstmt.setInt(2, user.getUserid());
        int i = pstmt.executeUpdate();
        DataBaseUtils.relaseResouce(null, pstmt, connection);
        return i;
    }

    public static int addComment(Comment comment) {
        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        int rs = 0;

        String sql = "insert into comment(userid,toanid,text,sendtime) values(?,?,?,?)";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, comment.getUserid());
            pstmt.setInt(2, comment.getToanid());
            pstmt.setString(3, comment.getText());
            pstmt.setString(4, comment.getSendtime());
            rs = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(null, pstmt, conn);
        }
        return rs;
    }
}
