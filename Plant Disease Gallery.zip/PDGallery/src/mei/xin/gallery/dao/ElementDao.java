package mei.xin.gallery.dao;

import mei.xin.gallery.common.DataBaseUtils;
import mei.xin.gallery.model.Element;
import mei.xin.gallery.model.Pool;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ElementDao {


    public static int AddPic(Element element) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        int rs = 0;

        String sql = "insert into databaseelement(did,upuserid,filename) values(?,?,?)";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, element.getDid());
            pstmt.setInt(2, element.getUpuserid());
            pstmt.setString(3, element.getFilename());
            rs = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(null, pstmt, conn);
        }
        return rs;
    }


    public static int MarkPic(Element element) {
        return 0;
    }

    public static List<Element> GetMyUploadPic(int userid) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Element> resmyelements = new ArrayList<Element>();
        resmyelements.clear();

        String sql = "select * from databaseelement where upuserid=? and isdelete = 0";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, userid);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                int eid = rs.getInt("eid");
                int did = rs.getInt("did");
                String title = rs.getString("title");
                String text = rs.getString("text");
                String label = rs.getString("label");
                String diseasespestsinfo = rs.getString("diseasespestsinfo");
                int ismark = rs.getInt("ismark");
                int upuserid = rs.getInt("upuserid");
                int markuserid = rs.getInt("markuserid");
                int autosave = rs.getInt("autosave");
                int aiscan = rs.getInt("aiscan");
                int isdelete = rs.getInt("isdelete");
                String filename = rs.getString("filename");

                Element element = new Element(eid, did, title, text, label, diseasespestsinfo, ismark, upuserid, markuserid, autosave, aiscan, isdelete, filename);

                resmyelements.add(element);
            }
        } catch (
                SQLException e) {
            resmyelements.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return resmyelements;

    }

    public static List<Element> GetAllUploadPicByDbDid(int bydid) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Element> res = new ArrayList<Element>();
        res.clear();

        String sql = "select * from databaseelement where did=?";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, bydid);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                int eid = rs.getInt("eid");
                int did = rs.getInt("did");
                String title = rs.getString("title");
                String text = rs.getString("text");
                String label = rs.getString("label");
                String diseasespestsinfo = rs.getString("diseasespestsinfo");
                int ismark = rs.getInt("ismark");
                int upuserid = rs.getInt("upuserid");
                int markuserid = rs.getInt("markuserid");
                int autosave = rs.getInt("autosave");
                int aiscan = rs.getInt("aiscan");
                int isdelete = rs.getInt("isdelete");
                String filename = rs.getString("filename");

                Element element = new Element(eid, did, title, text, label, diseasespestsinfo, ismark, upuserid, markuserid, autosave, aiscan, isdelete, filename);

                res.add(element);
            }
        } catch (
                SQLException e) {
            res.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return res;

    }

    public static int DeletePicByEid(int eid) {
        int i = 0;
//        String sql = "delete from databaseelement where eid = ?";
//        Connection connection = DataBaseUtils.getConnection();
//        PreparedStatement pstmt = null;
//        try {
//            pstmt = connection.prepareStatement(sql);
//            pstmt.setInt(1, eid);
//            i = pstmt.executeUpdate();
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }finally {
//            DataBaseUtils.relaseResouce(null, pstmt, connection);
//        }


        String sql = "update databaseelement set isdelete= 1 where eid = ?";
        Connection connection = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, eid);
            i = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(null, pstmt, connection);
        }

        return i;

    }

    public static List<Element> searchElementsByKey(String search_db_key) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Element> res = new ArrayList<Element>();
        res.clear();

        String sql = "select * from databaseelement where ( title like ? or text like ? or label like ? or diseasespestsinfo like ?) and isdelete = 0";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + search_db_key + "%");
            pstmt.setString(2, "%" + search_db_key + "%");
            pstmt.setString(3, "%" + search_db_key + "%");
            pstmt.setString(4, "%" + search_db_key + "%");
            rs = pstmt.executeQuery();
            while (rs.next()) {

                int eid = rs.getInt("eid");
                int did = rs.getInt("did");
                String title = rs.getString("title");
                String text = rs.getString("text");
                String label = rs.getString("label");
                String diseasespestsinfo = rs.getString("diseasespestsinfo");
                int ismark = rs.getInt("ismark");
                int upuserid = rs.getInt("upuserid");
                int markuserid = rs.getInt("markuserid");
                int autosave = rs.getInt("autosave");
                int aiscan = rs.getInt("aiscan");
                int isdelete = rs.getInt("isdelete");
                String filename = rs.getString("filename");

                Element element = new Element(eid, did, title, text, label, diseasespestsinfo, ismark, upuserid, markuserid, autosave, aiscan, isdelete, filename);

                res.add(element);
            }
        } catch (
                SQLException e) {
            res.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return res;
    }

    public static List<Element> getAllPic() {
        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Element> res = new ArrayList<Element>();
        res.clear();

        String sql = "select * from databaseelement where isdelete = 0";
        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                int eid = rs.getInt("eid");
                int did = rs.getInt("did");
                String title = rs.getString("title");
                String text = rs.getString("text");
                String label = rs.getString("label");
                String diseasespestsinfo = rs.getString("diseasespestsinfo");
                int ismark = rs.getInt("ismark");
                int upuserid = rs.getInt("upuserid");
                int markuserid = rs.getInt("markuserid");
                int autosave = rs.getInt("autosave");
                int aiscan = rs.getInt("aiscan");
                int isdelete = rs.getInt("isdelete");
                String filename = rs.getString("filename");

                Element element = new Element(eid, did, title, text, label, diseasespestsinfo, ismark, upuserid, markuserid, autosave, aiscan, isdelete, filename);

                res.add(element);
            }
        } catch (
                SQLException e) {
            res.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return res;
    }

    public static List<Element> getIsMark(int i) {
        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Element> res = new ArrayList<Element>();
        res.clear();

        String sql = "select * from databaseelement where ismark = ? and isdelete = 0";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, i);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                int eid = rs.getInt("eid");
                int did = rs.getInt("did");
                String title = rs.getString("title");
                String text = rs.getString("text");
                String label = rs.getString("label");
                String diseasespestsinfo = rs.getString("diseasespestsinfo");
                int ismark = rs.getInt("ismark");
                int upuserid = rs.getInt("upuserid");
                int markuserid = rs.getInt("markuserid");
                int autosave = rs.getInt("autosave");
                int aiscan = rs.getInt("aiscan");
                int isdelete = rs.getInt("isdelete");
                String filename = rs.getString("filename");

                Element element = new Element(eid, did, title, text, label, diseasespestsinfo, ismark, upuserid, markuserid, autosave, aiscan, isdelete, filename);

                res.add(element);
            }
        } catch (
                SQLException e) {
            res.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return res;
    }

    public static List<Element> getByDid(int didin) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Element> res = new ArrayList<Element>();
        res.clear();

        String sql = "select * from databaseelement where did = ? and isdelete = 0";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, didin);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                int eid = rs.getInt("eid");
                int did = rs.getInt("did");
                String title = rs.getString("title");
                String text = rs.getString("text");
                String label = rs.getString("label");
                String diseasespestsinfo = rs.getString("diseasespestsinfo");
                int ismark = rs.getInt("ismark");
                int upuserid = rs.getInt("upuserid");
                int markuserid = rs.getInt("markuserid");
                int autosave = rs.getInt("autosave");
                int aiscan = rs.getInt("aiscan");
                int isdelete = rs.getInt("isdelete");
                String filename = rs.getString("filename");

                Element element = new Element(eid, did, title, text, label, diseasespestsinfo, ismark, upuserid, markuserid, autosave, aiscan, isdelete, filename);

                res.add(element);
            }
        } catch (
                SQLException e) {
            res.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return res;

    }

    public static Element getByEid(int eidin) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Element element = null;

        String sql = "select * from databaseelement where eid = ? and isdelete = 0";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, eidin);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                int eid = rs.getInt("eid");
                int did = rs.getInt("did");
                String title = rs.getString("title");
                String text = rs.getString("text");
                String label = rs.getString("label");
                String diseasespestsinfo = rs.getString("diseasespestsinfo");
                int ismark = rs.getInt("ismark");
                int upuserid = rs.getInt("upuserid");
                int markuserid = rs.getInt("markuserid");
                int autosave = rs.getInt("autosave");
                int aiscan = rs.getInt("aiscan");
                int isdelete = rs.getInt("isdelete");
                String filename = rs.getString("filename");

                element = new Element(eid, did, title, text, label, diseasespestsinfo, ismark, upuserid, markuserid, autosave, aiscan, isdelete, filename);

            }
        } catch (
                SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return element;
    }

    public static int UpdateInfo(Element element) {

        int i = 0;

        int eid = element.getEid();
        String title = element.getTitle();
        String text = element.getText();
        String label = element.getLabel();
        String diseasespestsinfo = element.getDiseasespestsinfo();
        int markuserid = element.getMarkuserid();
        int did = element.getDid();

        String sql = "update databaseelement set title = ? , text= ? , label = ? , diseasespestsinfo =? , markuserid =? , did = ? , ismark = 1  where eid = ?";
        Connection connection = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, title);
            pstmt.setString(2, text);
            pstmt.setString(3, label);
            pstmt.setString(4, diseasespestsinfo);
            pstmt.setInt(5, markuserid);
            pstmt.setInt(6, did);
            pstmt.setInt(7, eid);
            i = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(null, pstmt, connection);
        }
        return i;
    }
}
