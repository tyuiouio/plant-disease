package mei.xin.gallery.dao;

import mei.xin.gallery.common.DataBaseUtils;
import mei.xin.gallery.common.DateUtils;
import mei.xin.gallery.model.Announcement;
import mei.xin.gallery.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserDao {

    public static int Updateuserinfo(User user) throws SQLException {

        String sql = "update user set username= ? , password= ? , email= ? , tel =? , sex = ?  where userid = ?";   // , updatedate = ?

        Connection connection = DataBaseUtils.getConnection();
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setString(1, user.getUsername());
        pstmt.setString(2, user.getPassword());
        pstmt.setString(3, user.getEmail());
        pstmt.setString(4, user.getTel());
        pstmt.setString(5, user.getSex());
        pstmt.setInt(6, user.getUserid());
        // todo 更新时间
//        pstmt.setTimestamp(7, DateUtils.getNowDateInSql());

        int i = pstmt.executeUpdate();
        DataBaseUtils.relaseResouce(null, pstmt, connection);
        return i;
    }

    public static int Updatesubscribe(User user) throws SQLException {

        String sql = "update user set subscribe= ? where userid =? ";

        Connection connection = DataBaseUtils.getConnection();
        PreparedStatement pstmt = connection.prepareStatement(sql);
        pstmt.setString(1, user.getSubscribe());
        pstmt.setInt(2, user.getUserid());

        int i = pstmt.executeUpdate();
        DataBaseUtils.relaseResouce(null, pstmt, connection);
        return i;
    }


    public static List<User> getAllUserName() {
        List<User> res = new ArrayList<User>();
        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        res.clear();

        String sql = "select * from user";

        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                int userid = rs.getInt("userid");
                String username = rs.getString("username");
                User user = new User();
                user.setUserid(userid);
                user.setUsername(username);
                res.add(user);
            }
        } catch (SQLException e) {
            res.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return res;
    }

    public static List<User> getAllUser() {

        List<User> userlist = new ArrayList<User>();

        List<Announcement> res = new ArrayList<Announcement>();
        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String sql = "select * from user";

        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {

                int userid = rs.getInt("userid");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String email = rs.getString("email");
                String sex = rs.getString("sex");
                String tel = rs.getString("tel");
                String usertype = rs.getString("usertype");
                int isadmin = rs.getInt("isadmin");
                int isdelete = rs.getInt("isdelete");
                Date uplogindate = rs.getTimestamp("uplogindate");
                Date createdate = rs.getTimestamp("createdate");
                Date updatedate = rs.getTimestamp("updatedate");

                User user = new User();
                user.setUserid(userid);
                user.setUsername(username);
                user.setPassword(password);
                user.setEmail(email);
                user.setSex(sex);
                user.setTel(tel);
                user.setUsertype(usertype);
                user.setIsadmin(isadmin);
                user.setIsdelete(isdelete);
                user.setUplogindate(uplogindate);
                user.setCreatedate(createdate);
                user.setUpdatedate(updatedate);
                userlist.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return userlist;
    }
}
