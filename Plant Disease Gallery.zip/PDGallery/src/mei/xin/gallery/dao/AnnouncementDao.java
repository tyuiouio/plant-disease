package mei.xin.gallery.dao;

import mei.xin.gallery.common.DataBaseUtils;
import mei.xin.gallery.common.DateUtils;
import mei.xin.gallery.model.Announcement;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnnouncementDao {
    public static List<Announcement> getAllAnnouncement() {

        List<Announcement> res = new ArrayList<Announcement>();
        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        res.clear();

        String sql = "select * from announcement where isdelete=0";

        try {
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                int anid = rs.getInt("anid");
                int userid = rs.getInt("userid");
                String title = rs.getString("title");
                String text = rs.getString("text");
                String link = rs.getString("link");
                int click = rs.getInt("click");
                String uploadtime = rs.getString("uploadtime");
                String createtime = rs.getString("createtime");
                String updatetime = rs.getString("updatetime");
                int isdelete = rs.getInt("isdelete");
                Announcement announcement = new Announcement(anid, userid, title, text, link, click, uploadtime, createtime, updatetime, isdelete);
//                System.err.println(announcement.toString());
                res.add(announcement);
            }
        } catch (SQLException e) {
            res.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return res;
    }

    public static Announcement getAnnouncementByAnid(int anidin) {

        Announcement announcement = null;
        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String sql = "select * from announcement where anid = ?";

        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, anidin);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                int anid = rs.getInt("anid");
                int userid = rs.getInt("userid");
                String title = rs.getString("title");
                String text = rs.getString("text");
                String link = rs.getString("link");
                int click = rs.getInt("click");
                String uploadtime = rs.getString("uploadtime");
                String createtime = rs.getString("createtime");
                String updatetime = rs.getString("updatetime");
                int isdelete = rs.getInt("isdelete");
                announcement = new Announcement(anid, userid, title, text, link, click, uploadtime, createtime, updatetime, isdelete);
//                System.err.println(announcement.toString());
            }
        } catch (
                SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return announcement;
    }

    public static int AnnouncementClickPlusPlus(int anidin) {

        String sql = "update announcement set click=click+1 where anid = ?";

        int i = 0;
        Connection connection = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, anidin);
            i = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(null, pstmt, connection);
        }
        return i;
    }

    public static List<Announcement> SearchByKey(String search_key) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Announcement> result = new ArrayList<Announcement>();
        result.clear();

        String sql = "select * from announcement where ( title like ? or text like ? ) and isdelete = 0 ";

        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + search_key + "%");
            pstmt.setString(2, "%" + search_key + "%");
            rs = pstmt.executeQuery();

            while (rs.next()) {

                int anid = rs.getInt("anid");
                int userid = rs.getInt("userid");
                int click = rs.getInt("click");
                int isdelete = rs.getInt("isdelete");

                String title = rs.getString("title");
                String text = rs.getString("text");
                String link = rs.getString("link");

                String uploadtime = String.valueOf(rs.getDate("uploadtime"));
                String createtime = String.valueOf(rs.getDate("createtime"));
                String updatetime = String.valueOf(rs.getDate("updatetime"));

                Announcement announcement = new Announcement(anid, userid, title, text, link, click, uploadtime, createtime, updatetime, isdelete);

                System.out.println( announcement.toString());

                result.add(announcement);

            }
        } catch (SQLException e) {
            result.clear();
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        return result;
    }

    public static int addAnnouncement(Announcement announcement) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        int rs = 0;

        Timestamp uploadtime = DateUtils.getNowDateInSql();
        Timestamp createtime = DateUtils.getNowDateInSql();
        Timestamp updatetime = DateUtils.getNowDateInSql();

        String sql = "insert into announcement(userid,title,text,link,uploadtime,createtime,updatetime) values(?,?,?,?,?,?,?)";
        try {
            pstmt = conn.prepareStatement(sql);



            pstmt.setInt(1, announcement.getUserid());
            pstmt.setString(2, announcement.getTitle());
            pstmt.setString(3, announcement.getText());
            pstmt.setString(4, announcement.getLink());
            pstmt.setTimestamp(5,uploadtime);
            pstmt.setTimestamp(6,createtime);
            pstmt.setTimestamp(7,updatetime);

            rs = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(null, pstmt, conn);
        }
        return rs;

    }

    public static int deleteAnnouncementByAnid(int anidin) {

        String sql = "update announcement set isdelete = 1 where anid = ?";

        int i = 0;
        Connection connection = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        try {
            pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, anidin);
            i = pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(null, pstmt, connection);
        }
        return i;
    }


    // todo insert
    // todo update
    // todo delete

}
