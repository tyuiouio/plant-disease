package mei.xin.gallery.model;

import java.util.Date;

public class User {

    private int userid;
    private String usertoken;
    private String username;
    private String password;
    private String email;
    private String sex;
    private String tel;
    private String subscribe;
    private String usertype;
    private int isadmin;
    private int isdelete;
    private Date uplogindate;
    private Date createdate;
    private Date updatedate;

    public User() {
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public User(int userid, String usertoken, String username, String password, String email, String sex, String tel, String subscribe, String usertype, int isadmin, int isdelete, Date uplogindate, Date createdate, Date updatedate) {
        this.userid = userid;
        this.usertoken = usertoken;
        this.username = username;
        this.password = password;
        this.email = email;
        this.sex = sex;
        this.tel = tel;
        this.subscribe = subscribe;
        this.usertype = usertype;
        this.isadmin = isadmin;
        this.isdelete = isdelete;
        this.uplogindate = uplogindate;
        this.createdate = createdate;
        this.updatedate = updatedate;
    }

    @Override
    public String toString() {
        return "User{" +
                "userid=" + userid +
                ", usertoken='" + usertoken + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", email='" + email + '\'' +
                ", sex='" + sex + '\'' +
                ", tel='" + tel + '\'' +
                ", subscribe='" + subscribe + '\'' +
                ", usertype='" + usertype + '\'' +
                ", isadmin=" + isadmin +
                ", isdelete=" + isdelete +
                ", uplogindate=" + uplogindate +
                ", createdate=" + createdate +
                ", updatedate=" + updatedate +
                '}';
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getUsertoken() {
        return usertoken;
    }

    public void setUsertoken(String usertoken) {
        this.usertoken = usertoken;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(String subscribe) {
        this.subscribe = subscribe;
    }

    public String getUsertype() {
        return usertype;
    }

    public void setUsertype(String usertype) {
        this.usertype = usertype;
    }

    public int getIsadmin() {
        return isadmin;
    }

    public void setIsadmin(int isadmin) {
        this.isadmin = isadmin;
    }

    public int getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(int isdelete) {
        this.isdelete = isdelete;
    }

    public Date getUplogindate() {
        return uplogindate;
    }

    public void setUplogindate(Date uplogindate) {
        this.uplogindate = uplogindate;
    }

    public Date getCreatedate() {
        return createdate;
    }

    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }
}
