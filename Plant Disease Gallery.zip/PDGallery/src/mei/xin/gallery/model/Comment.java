package mei.xin.gallery.model;

public class Comment {
    private int coid;
    private String commenttype;
    private int arid;
    private int anid;
    private int userid;
    private String totype;
    private int touserid;
    private int toarid;
    private int toanid;
    private int isdelete;
    private String text;
    private int click;
    private String sendtime;

    public Comment() {
    }

    public Comment(int coid, String commenttype, int arid, int anid, int userid, String totype, int touserid, int toarid, int toanid, int isdelete, String text, int click, String sendtime) {
        this.coid = coid;
        this.commenttype = commenttype;
        this.arid = arid;
        this.anid = anid;
        this.userid = userid;
        this.totype = totype;
        this.touserid = touserid;
        this.toarid = toarid;
        this.toanid = toanid;
        this.isdelete = isdelete;
        this.text = text;
        this.click = click;
        this.sendtime = sendtime;
    }

    public int getCoid() {
        return coid;
    }

    public void setCoid(int coid) {
        this.coid = coid;
    }

    public String getCommenttype() {
        return commenttype;
    }

    public void setCommenttype(String commenttype) {
        this.commenttype = commenttype;
    }

    public int getArid() {
        return arid;
    }

    public void setArid(int arid) {
        this.arid = arid;
    }

    public int getAnid() {
        return anid;
    }

    public void setAnid(int anid) {
        this.anid = anid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getTotype() {
        return totype;
    }

    public void setTotype(String totype) {
        this.totype = totype;
    }

    public int getTouserid() {
        return touserid;
    }

    public void setTouserid(int touserid) {
        this.touserid = touserid;
    }

    public int getToarid() {
        return toarid;
    }

    public void setToarid(int toarid) {
        this.toarid = toarid;
    }

    public int getToanid() {
        return toanid;
    }

    public void setToanid(int toanid) {
        this.toanid = toanid;
    }

    public int getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(int isdelete) {
        this.isdelete = isdelete;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getClick() {
        return click;
    }

    public void setClick(int click) {
        this.click = click;
    }

    public String getSendtime() {
        return sendtime;
    }

    public void setSendtime(String sendtime) {
        this.sendtime = sendtime;
    }
}
