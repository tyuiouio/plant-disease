package mei.xin.gallery.model;

public class Element {

    private int eid;
    private int did;

    private String title;
    private String text;
    private String label;
    private String diseasespestsinfo;

    private int ismark;
    private int upuserid;
    private int markuserid;
    private int autosave;
    private int aiscan;
    private int isdelete;

    private String filename;

    public Element() {
    }

    public Element(int eid, int did, String title, String text, String label, String diseasespestsinfo, int ismark, int upuserid, int markuserid, int autosave, int aiscan, int isdelete, String filename) {
        this.eid = eid;
        this.did = did;
        this.title = title;
        this.text = text;
        this.label = label;
        this.diseasespestsinfo = diseasespestsinfo;
        this.ismark = ismark;
        this.upuserid = upuserid;
        this.markuserid = markuserid;
        this.autosave = autosave;
        this.aiscan = aiscan;
        this.isdelete = isdelete;
        this.filename = filename;
    }

    public int getEid() {
        return eid;
    }

    public void setEid(int eid) {
        this.eid = eid;
    }

    public int getDid() {
        return did;
    }

    public void setDid(int did) {
        this.did = did;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getDiseasespestsinfo() {
        return diseasespestsinfo;
    }

    public void setDiseasespestsinfo(String diseasespestsinfo) {
        this.diseasespestsinfo = diseasespestsinfo;
    }

    public int getIsmark() {
        return ismark;
    }

    public void setIsmark(int ismark) {
        this.ismark = ismark;
    }

    public int getUpuserid() {
        return upuserid;
    }

    public void setUpuserid(int upuserid) {
        this.upuserid = upuserid;
    }

    public int getMarkuserid() {
        return markuserid;
    }

    public void setMarkuserid(int markuserid) {
        this.markuserid = markuserid;
    }

    public int getAutosave() {
        return autosave;
    }

    public void setAutosave(int autosave) {
        this.autosave = autosave;
    }

    public int getAiscan() {
        return aiscan;
    }

    public void setAiscan(int aiscan) {
        this.aiscan = aiscan;
    }

    public int getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(int isdelete) {
        this.isdelete = isdelete;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }

    //    @Override
//    public int addDept(Dept dept) throws Exception {
//        String sql = "insert into dept(deptno,dname,loc) values(?,?,?)";
//        Connection connection = DBConnection.getConnection();
//        PreparedStatement pstmt = connection.prepareStatement(sql);
//        pstmt.setInt(1, dept.getDeptno());
//        pstmt.setString(2, dept.getDname());
//        pstmt.setString(3, dept.getLoc());
//        int i = pstmt.executeUpdate();
//        DBConnection.closeAll(null, pstmt, connection);
//        return i;
//    }
//
//    @Override
//    public int deleteDept(int deptno) throws Exception {
//        String sql = "delete from dept where deptno = ?";
//        Connection connection = DBConnection.getConnection();
//        PreparedStatement pstmt = connection.prepareStatement(sql);
//        pstmt.setInt(1, deptno);
//        int i = pstmt.executeUpdate();
//        DBConnection.closeAll(null, pstmt, connection);
//        return i;
//    }
//
//    @Override
//    public int updateDeptLoc(Dept dept) throws Exception {
//        String sql = "update dept set loc = ? where deptno =? ";
//        Connection connection = DBConnection.getConnection();
//        PreparedStatement pstmt = connection.prepareStatement(sql);
//        pstmt.setString(1, dept.getLoc());
//        pstmt.setInt(2, dept.getDeptno());
//        int i = pstmt.executeUpdate();
//        DBConnection.closeAll(null, pstmt, connection);
//        return i;
//    }
//
//    @Override
//    public List<Dept> findAll() throws Exception {
//        List<Dept> list = new ArrayList<Dept>();
//        String sql = "select * from dept";
//        Connection connection = DBConnection.getConnection();
//        PreparedStatement pstmt = connection.prepareStatement(sql);
//        ResultSet rs = pstmt.executeQuery();
//        while (rs.next()) {
//            Dept d = new Dept();
//            d.setDeptno(rs.getInt("deptno"));
//            d.setDname(rs.getString("dname"));
//            d.setLoc(rs.getString("loc"));
//            list.add(d);
//        }
//        DBConnection.closeAll(rs, pstmt, connection);
//        return list;
//    }
}
