package mei.xin.gallery.model;

public class Announcement {

    private int anid;
    private int userid;
    private String title;
    private String text;
    private String link;
    private int click;
    private String uploadtime;
    private String createtime;
    private String updatetime;
    private int isdelete;

    public Announcement() {
    }

    public Announcement(int anid, int userid, String title, String text, String link, int click, String uploadtime, String createtime, String updatetime, int isdelete) {
        this.anid = anid;
        this.userid = userid;
        this.title = title;
        this.text = text;
        this.link = link;
        this.click = click;
        this.uploadtime = uploadtime;
        this.createtime = createtime;
        this.updatetime = updatetime;
        this.isdelete = isdelete;
    }

    @Override
    public String toString() {
        return "Announcement{" +
                "anid=" + anid +
                ", userid=" + userid +
                ", title='" + title + '\'' +
                ", text='" + text + '\'' +
                ", link='" + link + '\'' +
                ", click=" + click +
                ", uploadtime='" + uploadtime + '\'' +
                ", createtime='" + createtime + '\'' +
                ", updatetime='" + updatetime + '\'' +
                ", isdelete=" + isdelete +
                '}';
    }

    public int getAnid() {
        return anid;
    }

    public void setAnid(int anid) {
        this.anid = anid;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public int getClick() {
        return click;
    }

    public void setClick(int click) {
        this.click = click;
    }

    public String getUploadtime() {
        return uploadtime;
    }

    public void setUploadtime(String uploadtime) {
        this.uploadtime = uploadtime;
    }

    public String getCreatetime() {
        return createtime;
    }

    public void setCreatetime(String createtime) {
        this.createtime = createtime;
    }

    public String getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(String updatetime) {
        this.updatetime = updatetime;
    }

    public int getIsdelete() {
        return isdelete;
    }

    public void setIsdelete(int isdelete) {
        this.isdelete = isdelete;
    }
}
