package mei.xin.gallery.model;

public class Pool {

    private int did;
    private String dname;
    private String introduction;
    private String link;
    private String logo;

    public Pool() {
    }

    public Pool(int did, String dname, String introduction, String link, String logo) {
        this.did = did;
        this.dname = dname;
        this.introduction = introduction;
        this.link = link;
        this.logo = logo;
    }

    @Override
    public String toString() {
        return "Pool{" +
                "did=" + did +
                ", dname='" + dname + '\'' +
                ", introduction='" + introduction + '\'' +
                ", link='" + link + '\'' +
                ", logo='" + logo + '\'' +
                '}';
    }

    public int getDid() {
        return did;
    }

    public void setDid(int did) {
        this.did = did;
    }

    public String getDname() {
        return dname;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getIntroduction() {
        return introduction;
    }

    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getLogo() {
        return logo;
    }

    public void setLogo(String logo) {
        this.logo = logo;
    }
}
