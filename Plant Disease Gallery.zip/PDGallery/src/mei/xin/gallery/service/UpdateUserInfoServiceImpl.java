package mei.xin.gallery.service;

import mei.xin.gallery.dao.UserDao;
import mei.xin.gallery.model.User;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UpdateUserInfoServiceImpl implements UpdateUserInfoService {
    @Override
    public List<Object> updateuserinfo(User user) throws SQLException {

        List<Object> result = new ArrayList<Object>();

        int i = UserDao.Updateuserinfo(user);

        if (i == 1) {
            result.add(true);
        } else {
            result.add(false);
        }
        return result;
    }

    public List<Object> Updatesubscribe(User user) {
        List<Object> result = new ArrayList<Object>();

        return result;
    }

}
