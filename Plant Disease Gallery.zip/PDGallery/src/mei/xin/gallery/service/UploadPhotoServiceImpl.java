package mei.xin.gallery.service;

import mei.xin.gallery.dao.ElementDao;
import mei.xin.gallery.model.Element;

import java.sql.SQLException;
import java.util.List;

public class UploadPhotoServiceImpl implements UploadPhotoService {

    public int UploadOnePic(Element element) {
        return ElementDao.AddPic(element);
    }

    @Override
    public int MarkPic(Element element) {
        return ElementDao.MarkPic(element);
    }

    @Override
    public List<Element> GetMyUploadPic(int userid) {
        return ElementDao.GetMyUploadPic(userid);
    }

    @Override
    public int DeletePicByEid(int eid) {
        return ElementDao.DeletePicByEid(eid);
    }

}
