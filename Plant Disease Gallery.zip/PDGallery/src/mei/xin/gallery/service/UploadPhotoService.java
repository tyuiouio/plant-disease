package mei.xin.gallery.service;

import mei.xin.gallery.model.Element;

import java.sql.SQLException;
import java.util.List;

public interface UploadPhotoService {
    public int UploadOnePic(Element element);
    public int MarkPic(Element element);
    public List<Element> GetMyUploadPic(int userid);
    public int DeletePicByEid(int eid);

}
