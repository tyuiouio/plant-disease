package mei.xin.gallery.service;

import mei.xin.gallery.model.User;

import java.sql.SQLException;
import java.util.List;

public interface UpdateUserInfoService {
    public List<Object> updateuserinfo(User user) throws SQLException;
    // to-do add updatesubsc

}
