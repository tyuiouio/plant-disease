package mei.xin.gallery.service;

import mei.xin.gallery.model.User;

import java.util.List;

public interface LoginService {
    public List<Object> checkUser(String name, String password);
    public List<Object> register(User user);

}
