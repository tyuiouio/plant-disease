package mei.xin.gallery.service;

import java.util.List;

public class LoginServiceTest {
    public static void main(String[] args) {

        LoginService loginService = new LoginServiceImpl();

//        List<Object> result = loginService.checkUser("admin", "admin");
//        if (result.size() == 2) {
//            System.out.println(result.get(0));
//            System.out.println(result.get(1).toString());
//        } else if (result.size() == 1) {
//            System.out.println(result.get(0));
//        } else {
//            System.out.println("result.get(0) is null");
//        }

//        List<Object> result = loginService.register("testimpl","impl");
//        for (int i = 0; i < result.size(); i++) {
//            System.out.println(result.get(i));
//        }



        

    }
}
