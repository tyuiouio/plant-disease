package mei.xin.gallery.service;

import com.sun.deploy.util.OrderedHashSet;
import mei.xin.gallery.common.DataBaseUtils;
import mei.xin.gallery.common.DateUtils;
import mei.xin.gallery.model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LoginServiceImpl implements LoginService {


    public List<Object> checkUser(String username_in, String password_in) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<Object> result = new ArrayList<Object>();

        String sql = "select * from user where username = ? and password = ?";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, username_in);
            pstmt.setString(2, password_in);
            rs = pstmt.executeQuery();
            if (rs.next()) {

                int userid = rs.getInt("userid");
                String usertoken = rs.getString("usertoken");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String email = rs.getString("email");
                String sex = rs.getString("sex");
                String tel = rs.getString("tel");
                String subscribe = rs.getString("subscribe");
                String usertype = rs.getString("usertype");
                int isadmin = rs.getInt("isadmin");
                int isdelete = rs.getInt("isdelete");
                Date uplogindate = rs.getDate("uplogindate");
                Date createdate = rs.getDate("createdate");
                Date updatedate = rs.getDate("updatedate");

                User user = new User(userid, usertoken, username, password, email, sex, tel, subscribe, usertype, isadmin, isdelete, uplogindate, createdate, updatedate);
                result.add(true);
                result.add(user);

                // todo 更新上次登录时间
                // pstmt.setTimestamp(7, DateUtils.getNowDateInSql());

            } else {
                result.clear();
                result.add(false);
            }
        } catch (SQLException e) {
            result.clear();
            result.add(false);
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(rs, pstmt, conn);
        }
        if (result.size() < 2) result.set(0, false);
        return result;
    }

    public List<Object> register(User user) {

        Connection conn = DataBaseUtils.getConnection();
        PreparedStatement pstmt = null;
        List<Object> result = new ArrayList<Object>();

        String sql = "insert into user(username,password,email,sex,tel,usertype,uplogindate,createdate,updatedate) values(?,?,?,?,?,?,?,?,?)";
        try {
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getEmail());
            pstmt.setString(4, user.getSex());
            pstmt.setString(5, user.getTel());
            pstmt.setString(6, user.getUsertype());
            pstmt.setString(7, DateUtils.getNowDate());
            pstmt.setString(8, DateUtils.getNowDate());
            pstmt.setString(9, DateUtils.getNowDate());

//            System.out.println(user.getSex() + "  " + user.getUsertype());

            int rs = pstmt.executeUpdate();

            if (rs > 0) {
                result.add(true);
                result.add("注册成功！");
            } else {
                result.clear();
                result.add(false);
                result.add("注册失败，请更换用户名后重试！");
            }
        } catch (SQLException e) {
            result.clear();
            result.add(false);
            result.add("注册失败，请更换用户名后重试!!!");
            e.printStackTrace();
        } finally {
            DataBaseUtils.relaseResouce(null, pstmt, conn);
        }
        if (result.size() < 2) result.set(0, false);
        return result;
    }
}
